(function(){
var D=['N','E','S','W'],NAME={N:'North',E:'East',S:'South',W:'West'};
var P=[{g:['N','S'],d:6,s:'g'},{g:['N','S'],d:1.5,s:'y'},{g:[],d:1,s:'r'},{g:['E','W'],d:6,s:'g'},{g:['E','W'],d:1.5,s:'y'},{g:[],d:1,s:'r'}];
var OFF={N:0,E:2,S:4.5,W:7};
var mode='sync',paused=false,speed=1,t=0,pi=0,pt=0,cars=[],passed=0,crashes=0,clash=false,spawn={N:0.3,E:0.8,S:1.2,W:0.5},logs=[],prev={};
var LAMP={N:[132,118],S:[254,262],W:[118,254],E:[262,132]};
var $=function(i){return document.getElementById(i)};
var NS='http://www.w3.org/2000/svg';

function buildLamps(){
var h='';
D.forEach(function(d){var p=LAMP[d];
h+='<g transform="translate('+p[0]+','+p[1]+')"><rect width="16" height="40" rx="4" fill="#15191b" stroke="#000" stroke-opacity=".4"/>'+
['r','y','g'].map(function(c,i){return '<circle id="L'+d+c+'" cx="8" cy="'+(8+i*12)+'" r="4.5" fill="#444"/>'}).join('')+
'<text x="8" y="'+(d==='N'||d==='E'?-4:52)+'" font-size="10" font-weight="700" text-anchor="middle" fill="#fff">'+d+'</text></g>';});
$('lamps').innerHTML=h;}

function sig(d){
if(mode==='sync'){var p=P[pi];return p.g.indexOf(d)>=0?p.s:'r';}
var u=(t+OFF[d])%9;return u<4?'g':u<5?'y':'r';}

function pos2xy(c){
switch(c.d){case 'N':return [180,c.p];case 'S':return [220,400-c.p];case 'W':return [c.p,220];default:return [400-c.p,180];}}

function addLog(m){logs.unshift(m);if(logs.length>7)logs.pop();
$('log').innerHTML=logs.map(function(x){return '<li>'+x+'</li>'}).join('');}

function reset(){cars=[];passed=0;crashes=0;clash=false;t=0;pi=0;pt=0;prev={};logs=[];
addLog(mode==='sync'?'Controller started: mutex is free':'Controller started: no mutex, signals run independently');}

function phaseLog(){
var p=P[pi];
if(p.s==='g')addLog((p.g.join('')==='NS'?'North–South':'East–West')+' acquires mutex → green');
else if(p.s==='y')addLog((P[pi].g.join('')==='NS'?'North–South':'East–West')+' yellow');
else addLog('Mutex released → all red');}

function step(dt){
dt*=speed;t+=dt;
if(mode==='sync'){pt+=dt;if(pt>=P[pi].d){pt=0;pi=(pi+1)%P.length;phaseLog();}}
else{D.forEach(function(d){var s=sig(d);if(prev[d]!==s){if(prev[d]!==undefined)addLog(NAME[d]+' → '+(s==='g'?'green':s==='y'?'yellow':'red'));prev[d]=s;}});}
D.forEach(function(d){spawn[d]-=dt;if(spawn[d]<=0){spawn[d]=1.4+Math.random()*2.2;
var near=cars.some(function(c){return c.d===d&&c.p<30});if(!near)cars.push({d:d,p:-10,hit:false,done:false});}});
D.forEach(function(d){
var g=sig(d)==='g',list=cars.filter(function(c){return c.d===d}).sort(function(a,b){return b.p-a.p});
list.forEach(function(c,i){
var lim=1e9;if(i>0)lim=list[i-1].p-19;
if(!g&&c.p<=148)lim=Math.min(lim,148);
c.p=Math.max(c.p,Math.min(c.p+62*dt,lim));
if(!c.done&&c.p>250){c.done=true;passed++;}});});
cars=cars.filter(function(c){return c.p<430});
var ns=false,ew=false;
cars.forEach(function(c){if(c.p>152&&c.p<248){if(c.d==='N'||c.d==='S')ns=true;else ew=true;}});
var now=ns&&ew;
if(now){cars.forEach(function(c){if(c.p>152&&c.p<248)c.hit=true;});}
if(now&&!clash){crashes++;addLog('<span style="color:var(--bad)">Collision! Two roads in the crossing together</span>');}
clash=now;}

function render(){
D.forEach(function(d){var s=sig(d);
[['r','#e5483c'],['y','#f0b429'],['g','#34c26a']].forEach(function(x){
$('L'+d+x[0]).setAttribute('fill',s===x[0]?x[1]:'#3a3f42');});});
var h='',wait=0;
cars.forEach(function(c){var xy=pos2xy(c),v=(c.d==='N'||c.d==='S');
if(c.p<=150&&c.p>0&&sig(c.d)!=='g')wait++;
h+='<rect x="'+(xy[0]-(v?5:9))+'" y="'+(xy[1]-(v?9:5))+'" width="'+(v?10:18)+'" height="'+(v?18:10)+'" rx="2.5" fill="'+(c.hit?'var(--bad)':'var(--car)')+'" stroke="#000" stroke-opacity=".35" stroke-width=".6"/>';});
$('cars').innerHTML=h;
var L=$('lock').firstElementChild;
if(mode==='sync'){var p=P[pi];if(p.g.length){L.textContent='Held by '+(p.g.join('')==='NS'?'N–S':'E–W');L.className='held';}else{L.textContent='Free';L.className='';}}
else{L.textContent='No lock';L.className='';}
$('crash').firstElementChild.textContent=crashes;
$('pass').firstElementChild.textContent=passed;
$('wait').firstElementChild.textContent=wait;}

function setMode(m){mode=m;$('mSync').setAttribute('aria-pressed',m==='sync');$('mFree').setAttribute('aria-pressed',m==='free');reset();render();}
$('mSync').onclick=function(){setMode('sync')};
$('mFree').onclick=function(){setMode('free')};
$('pause').onclick=function(){paused=!paused;this.setAttribute('aria-pressed',paused);this.textContent=paused?'Resume':'Pause';};
$('spd').oninput=function(){speed=parseFloat(this.value)};

buildLamps();reset();render();
var last=performance.now();
function loop(n){var dt=Math.min((n-last)/1000,0.05);last=n;if(!paused){step(dt);render();}requestAnimationFrame(loop);}
requestAnimationFrame(loop);
})();

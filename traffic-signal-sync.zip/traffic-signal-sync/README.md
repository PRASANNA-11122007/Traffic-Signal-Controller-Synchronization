# Traffic Signal Controller - Synchronization

A four-way junction simulation that shows how a mutex (binary semaphore) keeps
conflicting roads from using the crossing at the same time.

## Files
- index.html - page structure (junction SVG, controls, stats, log)
- style.css  - styling (light and dark theme)
- script.js  - signal controller logic, car movement, collision detection

## How to run
Open index.html in any browser. No installation needed.

## Modes
- With mutex: North-South and East-West take turns holding the crossing lock. No collisions.
- No synchronization: every signal runs on its own timer, so both road pairs can enter the crossing together. Collisions show the race condition.
